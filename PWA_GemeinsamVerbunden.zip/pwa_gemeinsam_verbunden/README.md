# Gemeinsam Verbunden – Progressive Web App

Einfache, mobilfreundliche Buchungs- und Informationsseite für kulturelle Angebote in Pflegeheimen (Region Mansfeld-Südharz).

## Was die App kann

- Übersicht der Formate und Preise
- Anfrageformular (öffnet E-Mail an michaelgrum0267@gmail.com)
- Direkter Anruf-Button
- Installierbar auf dem Smartphone (PWA)
- Funktioniert auch offline (Grundseiten)

## Dateien

- `index.html` – Hauptseite
- `css/style.css` – Design (seniorenfreundlich, große Schrift)
- `js/app.js` – Formular-Logik
- `manifest.json` – PWA-Manifest
- `sw.js` – Service Worker (Offline)
- `icons/` – App-Icons

## So testen Sie die App

1. Ordner auf einen Webserver legen (oder lokal mit einem einfachen Server starten)
2. Im Browser öffnen (am besten Chrome oder Safari auf dem Handy)
3. „Zum Home-Bildschirm hinzufügen“ / „Installieren“ wählen

### Lokal testen (Beispiel)

```bash
cd pwa_gemeinsam_verbunden
python3 -m http.server 8080
```

Dann im Browser: http://localhost:8080

## Nächste mögliche Ausbauten

- Echter Kalender mit freien Terminen
- Backend / Formular-Versand ohne E-Mail-Programm
- Admin-Bereich für Terminverwaltung
- Echte App-Icons (192×192 und 512×512 PNG)

## Kontakt

Michael Grumbach  
Ulrichstraße 7, 06526 Sangerhausen  
Tel: 01525 5755159  
E-Mail: michaelgrum0267@gmail.com
