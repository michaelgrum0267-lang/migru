// Gemeinsam Verbunden – App + einfacher Kalender

const FORMATE = [
  { name: "Musiknachmittag / Singkreis", price: "95–120 €" },
  { name: "Lesung & Geschichtenrunde", price: "80–100 €" },
  { name: "Biografie-Kulturstunde", price: "100–130 €" },
  { name: "Kreativ-Workshop", price: "110–140 €" },
  { name: "Saisonales Festprogramm", price: "130–160 €" },
  { name: "Hybrid-Zuschlag (Livestream)", price: "+25–40 €" }
];

// Beispiel-freie Tage (können später aus einer echten Quelle kommen)
// Format: "YYYY-MM-DD"
const FREE_DAYS = [
  "2026-11-25", "2026-11-27", "2026-11-28",
  "2026-12-02", "2026-12-04", "2026-12-05", "2026-12-09", "2026-12-11", "2026-12-12",
  "2026-12-16", "2026-12-18", "2026-12-19",
  "2027-01-06", "2027-01-08", "2027-01-09", "2027-01-13", "2027-01-15", "2027-01-16",
  "2027-01-20", "2027-01-22", "2027-01-23", "2027-01-27", "2027-01-29", "2027-01-30"
];

const WEEKDAYS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
const MONTHS = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];

let currentYear, currentMonth;

function renderFormats() {
  const container = document.getElementById("formats");
  if (!container) return;
  container.innerHTML = FORMATE.map(f => `
    <div class="format-item">
      <span class="name">${f.name}</span>
      <span class="price">${f.price}</span>
    </div>
  `).join("");
}

function pad(n) { return n < 10 ? "0" + n : "" + n; }

function toKey(y, m, d) {
  return y + "-" + pad(m + 1) + "-" + pad(d);
}

function renderCalendar() {
  const el = document.getElementById("calendar");
  if (!el) return;

  const first = new Date(currentYear, currentMonth, 1);
  // Montag = 0 ... Sonntag = 6
  let startDay = first.getDay() - 1;
  if (startDay < 0) startDay = 6;

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  let html = `
    <div class="cal-nav">
      <button type="button" id="cal-prev">‹</button>
      <span class="month-label">${MONTHS[currentMonth]} ${currentYear}</span>
      <button type="button" id="cal-next">›</button>
    </div>
    <div class="calendar">
  `;

  WEEKDAYS.forEach(d => {
    html += `<div class="cal-header">${d}</div>`;
  });

  for (let i = 0; i < startDay; i++) {
    html += `<div class="cal-day empty"></div>`;
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const key = toKey(currentYear, currentMonth, d);
    const isFree = FREE_DAYS.includes(key);
    const cls = isFree ? "cal-day free" : "cal-day";
    html += `<div class="${cls}" data-date="${key}" data-free="${isFree}">${d}</div>`;
  }

  html += `</div>
    <div class="cal-legend">
      <span class="leg-free">Anfragbar</span>
      <span class="leg-busy">Belegt / nicht markiert</span>
    </div>
  `;

  el.innerHTML = html;

  document.getElementById("cal-prev").onclick = () => {
    currentMonth--;
    if (currentMonth < 0) { currentMonth = 11; currentYear--; }
    renderCalendar();
  };
  document.getElementById("cal-next").onclick = () => {
    currentMonth++;
    if (currentMonth > 11) { currentMonth = 0; currentYear++; }
    renderCalendar();
  };

  el.querySelectorAll(".cal-day.free").forEach(day => {
    day.onclick = () => {
      el.querySelectorAll(".cal-day.selected").forEach(s => s.classList.remove("selected"));
      day.classList.add("selected");
      const dateStr = day.dataset.date;
      const [y, m, d] = dateStr.split("-");
      const nice = parseInt(d,10) + ". " + MONTHS[parseInt(m,10)-1] + " " + y;
      document.getElementById("selected-date").textContent = "Ausgewählt: " + nice;
      const datumInput = document.getElementById("datum");
      if (datumInput) datumInput.value = nice;
    };
  });
}

function handleFormSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const data = {
    einrichtung: form.einrichtung.value.trim(),
    ort: form.ort.value.trim(),
    format: form.format.value,
    datum: form.datum.value.trim(),
    hybrid: form.hybrid.value,
    nachricht: form.nachricht.value.trim(),
    kontakt: form.kontakt.value.trim()
  };

  const subject = encodeURIComponent("Anfrage Kulturelles Angebot – " + data.einrichtung);
  const body = encodeURIComponent(
    "Hallo Herr Grumbach,\n\n" +
    "ich möchte ein kulturelles Angebot anfragen:\n\n" +
    "Einrichtung / Name: " + data.einrichtung + "\n" +
    "Ort / PLZ: " + (data.ort || "–") + "\n" +
    "Format: " + data.format + "\n" +
    "Wunschtermin: " + (data.datum || "–") + "\n" +
    "Hybrid (Livestream): " + data.hybrid + "\n" +
    "Nachricht: " + (data.nachricht || "–") + "\n" +
    "Kontakt: " + data.kontakt + "\n\n" +
    "Mit freundlichen Grüßen"
  );

  window.location.href = "mailto:michaelgrum0267@gmail.com?subject=" + subject + "&body=" + body;

  const msg = document.getElementById("success-msg");
  if (msg) msg.style.display = "block";
}

function registerSW() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js")
      .then(() => console.log("Service Worker ok"))
      .catch(err => console.log("SW Fehler:", err));
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const now = new Date();
  currentYear = now.getFullYear();
  currentMonth = now.getMonth();

  renderFormats();
  renderCalendar();

  const form = document.getElementById("booking-form");
  if (form) form.addEventListener("submit", handleFormSubmit);

  registerSW();
});
